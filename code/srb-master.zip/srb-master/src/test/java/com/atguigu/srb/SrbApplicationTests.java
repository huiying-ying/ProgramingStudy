package com.atguigu.srb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SrbApplicationTests {

    @Test
    void contextLoads() {
    }

}
