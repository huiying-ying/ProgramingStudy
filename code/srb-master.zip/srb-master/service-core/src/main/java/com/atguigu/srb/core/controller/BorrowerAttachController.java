package com.atguigu.srb.core.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 借款人上传资源表 前端控制器
 * </p>
 *
 * @author shuo
 * @since 2022-03-22
 */
@RestController
@RequestMapping("/borrowerAttach")
public class BorrowerAttachController {

}

